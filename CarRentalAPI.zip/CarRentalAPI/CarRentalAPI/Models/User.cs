﻿using System.ComponentModel.DataAnnotations;

namespace CarRentalAPI.Models
{
    public class User
    {
        [Key]
        public int UserID { get; set; }

        [Required, MaxLength(100)]
        public string FullName { get; set; } = string.Empty;

        [Required, EmailAddress, MaxLength(100)]
        public string Email { get; set; } = string.Empty;

        [MaxLength(10)]
        public string? Phone { get; set; }

        [Required]
        public string PasswordHash { get; set; } = string.Empty;

        public string? Address { get; set; }

        public string? ProfileImage { get; set; }
        public string? IDCardImage { get; set; }
        public string? DriverLicenseImage { get; set; }

        public string Role { get; set; } = "User";
        public bool IsActive { get; set; } = true;
        public bool IsLocked { get; set; } = false;

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;
    }
}
