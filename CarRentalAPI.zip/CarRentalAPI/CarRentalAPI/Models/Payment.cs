﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CarRentalAPI.Models
{
    public class Payment
    {
        [Key]
        public int PaymentID { get; set; }

        public int RentalID { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }

        [Required]
        public string PaymentMethod { get; set; } = "Cash"; // Cash | BankTransfer

        public string PaymentStatus { get; set; } = "Pending"; // Pending | Paid | Failed

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public Rental? Rental { get; set; }
    }
}
