﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace CarRentalAPI.Models
{
    public class Branch
    {
        [Key]
        public int BranchID { get; set; }

        [Required]
        [MaxLength(100)]
        public string BranchName { get; set; }

        public string? BranchImage { get; set; }

        [Required]
        [MaxLength(255)]
        public string Address { get; set; }

        [MaxLength(10)]
        public string? Phone { get; set; }

        public string? Description { get; set; }

        public int TotalVehicles { get; set; } = 0;

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        public bool IsActive { get; set; } = true;
        [JsonIgnore]
        public ICollection<Vehicle>? Vehicles { get; set; }
    }
}
