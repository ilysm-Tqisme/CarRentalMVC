﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace CarRentalAPI.Models
{
    public class VehicleType
    {
        [Key]
        public int TypeID { get; set; }

        [Required, MaxLength(50)]
        public string TypeName { get; set; } = string.Empty;

        [MaxLength(255)]
        public string? Description { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        [JsonIgnore]
        public ICollection<Vehicle>? Vehicles { get; set; }
    }
}
