﻿using System.ComponentModel.DataAnnotations;

namespace CarRentalAPI.Models
{
    public class PromotionCode
    {
        [Key]
        public int PromoID { get; set; }

        [Required]
        [MaxLength(50)]
        public string Code { get; set; } = "";

        [MaxLength(20)]
        public string DiscountType { get; set; } = "Percentage"; // Percentage or Fixed

        public decimal DiscountValue { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public bool IsActive { get; set; } = true;
    }
}
