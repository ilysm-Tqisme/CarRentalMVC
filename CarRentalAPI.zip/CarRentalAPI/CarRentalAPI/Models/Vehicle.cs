﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CarRentalAPI.Models
{
    public class Vehicle
    {
        [Key]
        public int VehicleID { get; set; }

        [Required]
        public string VehicleName { get; set; }

        public int BrandID { get; set; }
        public int TypeID { get; set; }
        public int BranchID { get; set; }

        public string? VehicleImage { get; set; }

        [Column(TypeName = "decimal(10,2)")]
        public decimal PricePerDay { get; set; }

        public int? Seats { get; set; }
        public string? Description { get; set; }
        public string? Status { get; set; } = "Available";
        public bool IsActive { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        [ForeignKey("BrandID")]
        public VehicleBrand? Brand { get; set; }

        [ForeignKey("TypeID")]
        public VehicleType? Type { get; set; }

        [ForeignKey("BranchID")]
        public Branch? Branch { get; set; }
    }
}
