﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace CarRentalAPI.Models
{
    public class VehicleBrand
    {
        [Key]
        public int BrandID { get; set; }

        [Required, MaxLength(50)]
        public string BrandName { get; set; } = string.Empty;

        public string? Description { get; set; }

        [MaxLength(500)]
        public string? LogoImage { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // 🚗 Một hãng có thể có nhiều xe
        [JsonIgnore]
        public ICollection<Vehicle>? Vehicles { get; set; }
    }
}
