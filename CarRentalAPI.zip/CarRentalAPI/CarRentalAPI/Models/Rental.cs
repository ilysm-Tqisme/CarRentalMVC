﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CarRentalAPI.Models
{
    [Table("Rentals")]
    public class Rental
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("User")]
        public int UserId { get; set; }
        public User? User { get; set; }

        [ForeignKey("Vehicle")]
        public int VehicleId { get; set; }
        public Vehicle? Vehicle { get; set; }

        [Required]
        public DateTime RentalDate { get; set; }  // Ngày mượn

        [Required]
        public DateTime ReturnDate { get; set; } // Ngày trả

        [Column(TypeName = "decimal(18,2)")]
        public decimal DailyRate { get; set; } // Giá mỗi ngày (snapshot từ Vehicle)

        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalPrice { get; set; } // Tổng giá = (ReturnDate - RentalDate).Days * DailyRate

        [Column(TypeName = "decimal(18,2)")]
        public decimal PaidAmount { get; set; } = 0;

        [Column(TypeName = "decimal(18,2)")]
        public decimal RemainingAmount { get; set; }

        // Status: Pending(chờ duyệt), Approved, Active(đang mượn), Completed, Rejected, Cancelled
        [Required]
        [MaxLength(50)]
        public string Status { get; set; } = "Pending";

        [MaxLength(500)]
        public string? RejectionReason { get; set; }

        [ForeignKey("ApprovedBy")]
        public int? ApprovedById { get; set; }
        public User? ApprovedBy { get; set; }

        public DateTime? ApprovedDate { get; set; }

        [Required]
        public DateTime CreatedDate { get; set; } = DateTime.Now;

        public DateTime? UpdatedDate { get; set; }

        [MaxLength(500)]
        public string? Notes { get; set; }

        public int? Rating { get; set; } // 1-5 stars
        [MaxLength(1000)]
        public string? Review { get; set; }
    }
}
