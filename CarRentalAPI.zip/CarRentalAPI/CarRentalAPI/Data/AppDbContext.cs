﻿using CarRentalAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CarRentalAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> opts) : base(opts) { }

        // 🔹 Các DbSet chính
        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Branch> Branches { get; set; } = null!;
        public DbSet<Vehicle> Vehicles { get; set; } = null!;
        public DbSet<VehicleType> VehicleTypes { get; set; } = null!;
        public DbSet<VehicleBrand> VehicleBrands { get; set; } = null!;
        public DbSet<Rental> Rentals { get; set; } = null!;
        public DbSet<Payment> Payments { get; set; } = null!;
        public DbSet<PromotionCode> PromotionCodes { get; set; } = null!;
        //public DbSet<Review> Reviews { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // ✅ Unique Email
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            // User - Rental (1:N)
            modelBuilder.Entity<Rental>()
                .HasOne(r => r.User)
                .WithMany()
                .HasForeignKey(r => r.UserId)
                .OnDelete(DeleteBehavior.Restrict);

            // Vehicle - Rental (1:N)
            modelBuilder.Entity<Rental>()
                .HasOne(r => r.Vehicle)
                .WithMany()
                .HasForeignKey(r => r.VehicleId)
                .OnDelete(DeleteBehavior.Restrict);

            // Admin approve Rental
            modelBuilder.Entity<Rental>()
                .HasOne(r => r.ApprovedBy)
                .WithMany()
                .HasForeignKey(r => r.ApprovedById)
                .OnDelete(DeleteBehavior.SetNull);

            // Index for better query performance
            modelBuilder.Entity<Rental>()
                .HasIndex(r => new { r.UserId, r.CreatedDate })
                .IsDescending(new bool[] { false, true });

            modelBuilder.Entity<Rental>()
                .HasIndex(r => new { r.VehicleId, r.Status });

            modelBuilder.Entity<Rental>()
                .HasIndex(r => r.Status);


            base.OnModelCreating(modelBuilder);
        }
    }
}
