﻿using CarRentalAPI.Models;
using CarRentalAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace CarRentalAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IUserService _service;

        public AuthController(IUserService service)
        {
            _service = service;
        }

        // 🟢 Đăng ký
        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterRequest req)
        {
            if (req.Password != req.ConfirmPassword)
                return BadRequest("Mật khẩu nhập lại không trùng khớp");

            // ✅ Kiểm tra email và số điện thoại trước khi tạo user
            var emailExist = await _service.IsEmailExistAsync(req.Email);
            if (emailExist)
                return BadRequest("Email đã tồn tại");

            var phoneExist = await _service.IsPhoneExistAsync(req.Phone);
            if (phoneExist)
                return BadRequest("Số điện thoại đã tồn tại");

            var user = new User
            {
                FullName = req.FullName,
                Email = req.Email,
                Phone = req.Phone,
                Address = req.Address
            };

            try
            {
                var result = await _service.RegisterAsync(user, req.Password);
                if (result == null)
                    return BadRequest("Đăng ký không thành công");

                return Ok(new { message = "Đăng ký thành công", user = result });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }


        // 🟢 Đăng nhập
        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginRequest req)
        {
            var token = await _service.LoginAsync(req.Email, req.Password);
            if (token == null)
                return Unauthorized("Sai email hoặc mật khẩu");

            return Ok(new { token });
        }

        // 🟢 Đổi mật khẩu
        [Authorize]
        [HttpPost("change-password")]
        public async Task<IActionResult> ChangePassword(ChangePasswordRequest req)
        {
            if (req.NewPassword != req.ConfirmNewPassword)
                return BadRequest("Mật khẩu mới nhập lại không trùng khớp");

            var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");
            var result = await _service.ChangePasswordAsync(userId, req.OldPassword, req.NewPassword);
            if (!result) return BadRequest("Mật khẩu cũ không đúng");
            return Ok("Đổi mật khẩu thành công");
        }

        // 🟢 Đăng xuất (client chỉ cần xoá token)
        [HttpPost("logout")]
        public IActionResult Logout()
        {
            return Ok("Đã đăng xuất (hãy xóa token ở client)");
        }
    }

    public record RegisterRequest(
        string FullName,
        string Email,
        string Phone,
        string Password,
        string ConfirmPassword,
        string Address);

    public record LoginRequest(string Email, string Password);
    public record ChangePasswordRequest(string OldPassword, string NewPassword, string ConfirmNewPassword);
}
