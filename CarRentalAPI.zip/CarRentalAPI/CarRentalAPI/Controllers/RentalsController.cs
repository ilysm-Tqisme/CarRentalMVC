﻿using CarRentalAPI.Data;
using CarRentalAPI.DTOs;
using CarRentalAPI.Models;
using CarRentalAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace CarRentalAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class RentalsController : ControllerBase
    {
        private readonly IRentalService _service;

        public RentalsController(IRentalService service)
        {
            _service = service;
        }

        private int GetUserId()
        {
            return int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0");
        }

        private bool IsAdmin()
        {
            return User.IsInRole("Admin");
        }

        // ==================== USER ENDPOINTS ====================

        // Tạo đơn thuê xe
        [HttpPost("create")]
        public async Task<IActionResult> CreateRental([FromBody] CreateRentalRequest req)
        {
            try
            {
                var userId = GetUserId();
                var result = await _service.CreateRentalAsync(userId, req);
                if (result == null)
                    return BadRequest("Không thể tạo đơn thuê");

                return Ok(new { message = "Tạo đơn thuê thành công", rental = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // Xem danh sách đơn thuê của tôi
        [HttpGet("my-rentals")]
        public async Task<IActionResult> GetMyRentals()
        {
            var userId = GetUserId();
            var rentals = await _service.GetUserRentalsAsync(userId);
            return Ok(rentals);
        }

        // Chi tiết đơn thuê
        [HttpGet("{rentalId}")]
        public async Task<IActionResult> GetRentalDetail(int rentalId)
        {
            var userId = GetUserId();
            var rental = await _service.GetRentalByIdAsync(rentalId, userId);
            if (rental == null)
                return NotFound("Không tìm thấy đơn thuê");

            return Ok(rental);
        }

        // User hủy đơn (chỉ Pending)
        [HttpPost("{rentalId}/cancel")]
        public async Task<IActionResult> CancelRental(int rentalId)
        {
            try
            {
                var userId = GetUserId();
                var result = await _service.CancelRentalAsync(rentalId, userId);
                if (!result)
                    return NotFound("Không tìm thấy đơn thuê");

                return Ok(new { message = "Hủy đơn thuê thành công" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // Tính giá realtime (cho frontend)
        [HttpPost("calculate-price")]
        public async Task<IActionResult> CalculatePrice([FromBody] CalculatePriceRequest req)
        {
            try
            {
                var result = await _service.CalculatePriceAsync(req);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // Đánh giá xe
        [HttpPost("{rentalId}/rate")]
        public async Task<IActionResult> RateRental(int rentalId, [FromBody] RatingRequest req)
        {
            try
            {
                var userId = GetUserId();
                var result = await _service.RateRentalAsync(rentalId, userId, req);
                if (!result)
                    return NotFound("Không tìm thấy đơn thuê");

                return Ok(new { message = "Đánh giá thành công" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // ==================== ADMIN ENDPOINTS ====================

        // Admin: Xem tất cả đơn thuê
        [HttpGet("admin/all")]
        public async Task<IActionResult> GetAllRentals([FromQuery] string? status = null)
        {
            if (!IsAdmin())
                return Forbid("Chỉ admin mới có quyền truy cập");

            var rentals = await _service.GetAllRentalsAsync(status);
            return Ok(rentals);
        }

        // Admin: Duyệt đơn thuê
        [HttpPost("admin/{rentalId}/approve")]
        public async Task<IActionResult> ApproveRental(int rentalId)
        {
            try
            {
                if (!IsAdmin())
                    return Forbid("Chỉ admin mới có quyền truy cập");

                var adminId = GetUserId();
                var result = await _service.ApproveRentalAsync(rentalId, adminId);
                if (result == null)
                    return NotFound("Không tìm thấy đơn thuê");

                return Ok(new { message = "Duyệt đơn thành công", rental = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // Admin: Từ chối đơn thuê
        [HttpPost("admin/{rentalId}/reject")]
        public async Task<IActionResult> RejectRental(int rentalId, [FromBody] Dictionary<string, string?> body)
        {
            try
            {
                if (!IsAdmin())
                    return Forbid("Chỉ admin mới có quyền truy cập");

                var reason = body.ContainsKey("reason") ? body["reason"] : null;
                var adminId = GetUserId();
                var result = await _service.RejectRentalAsync(rentalId, adminId, reason);
                if (result == null)
                    return NotFound("Không tìm thấy đơn thuê");

                return Ok(new { message = "Từ chối đơn thành công", rental = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // Admin: Hủy đơn (Admin)
        [HttpPost("admin/{rentalId}/cancel")]
        public async Task<IActionResult> AdminCancelRental(int rentalId, [FromBody] Dictionary<string, string?> body)
        {
            try
            {
                if (!IsAdmin())
                    return Forbid("Chỉ admin mới có quyền truy cập");

                var reason = body.ContainsKey("reason") ? body["reason"] : null;
                var adminId = GetUserId();
                var result = await _service.CancelRentalAdminAsync(rentalId, adminId, reason);
                if (result == null)
                    return NotFound("Không tìm thấy đơn thuê");

                return Ok(new { message = "Hủy đơn thành công", rental = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        // Admin: Thống kê
        [HttpGet("admin/statistics")]
        public async Task<IActionResult> GetStatistics([FromQuery] DateTime? fromDate, [FromQuery] DateTime? toDate)
        {
            if (!IsAdmin())
                return Forbid("Chỉ admin mới có quyền truy cập");

            var stats = await _service.GetStatisticsAsync(fromDate, toDate);
            return Ok(stats);
        }
    }
}
