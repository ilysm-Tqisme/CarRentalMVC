﻿using CarRentalAPI.Data;
using CarRentalAPI.DTOs;
using CarRentalAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CarRentalAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BranchesController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public BranchesController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // 🟢 GET: api/Branches
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var branches = await _context.Branches
                .OrderByDescending(b => b.CreatedAt)
                .ToListAsync();
            return Ok(branches);
        }

        // 🟢 GET: api/Branches/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var branch = await _context.Branches.FindAsync(id);
            if (branch == null)
                return NotFound(new { message = "Không tìm thấy chi nhánh!" });

            return Ok(branch);
        }

        [HttpPost]
        [RequestSizeLimit(10_000_000)]
        public async Task<IActionResult> Create([FromForm] BranchDTO dto)
        {
            string? imagePath = null;

            if (dto.ImageFile != null) // ✅ nhận từ form key = "ImageFile"
            {
                string folder = Path.Combine(_env.WebRootPath ?? "wwwroot", "uploads", "branches");
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);

                string fileName = $"{Guid.NewGuid()}_{dto.ImageFile.FileName}";
                string filePath = Path.Combine(folder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await dto.ImageFile.CopyToAsync(stream);
                }

                imagePath = $"/uploads/branches/{fileName}";
            }

            var branch = new Branch
            {
                BranchName = dto.BranchName,
                Address = dto.Address,
                Phone = dto.Phone,
                Description = dto.Description,
                BranchImage = imagePath,
                IsActive = dto.IsActive,
                CreatedAt = DateTime.Now,
                UpdatedAt = DateTime.Now
            };

            _context.Branches.Add(branch);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Thêm chi nhánh thành công!", branch });
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromForm] BranchDTO dto)
        {
            var branch = await _context.Branches.FindAsync(id);
            if (branch == null)
                return NotFound(new { message = "Không tìm thấy chi nhánh!" });

            branch.BranchName = dto.BranchName;
            branch.Address = dto.Address;
            branch.Phone = dto.Phone;
            branch.Description = dto.Description;
            branch.IsActive = dto.IsActive;
            branch.UpdatedAt = DateTime.Now;

            if (dto.ImageFile != null)
            {
                string folder = Path.Combine(_env.WebRootPath ?? "wwwroot", "uploads", "branches");
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);

                string fileName = $"{Guid.NewGuid()}_{dto.ImageFile.FileName}";
                string filePath = Path.Combine(folder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await dto.ImageFile.CopyToAsync(stream);
                }

                branch.BranchImage = $"/uploads/branches/{fileName}";
            }

            _context.Branches.Update(branch);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Cập nhật chi nhánh thành công!", branch });
        }

        // ✅ Kiểm tra trùng chi nhánh
        [HttpGet("check-duplicate")]
        public async Task<IActionResult> CheckDuplicate(string name, string phone)
        {
            var exists = await _context.Branches
                .AnyAsync(b => b.BranchName == name || b.Phone == phone);

            if (exists)
                return BadRequest(new { message = "Chi nhánh hoặc số điện thoại đã tồn tại!" });

            return Ok(new { message = "Hợp lệ, không bị trùng." });
        }

        // 🔴 DELETE: api/Branches/{id} (Ẩn hoặc xóa)
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var branch = await _context.Branches.FindAsync(id);
            if (branch == null)
                return NotFound(new { message = "Không tìm thấy chi nhánh!" });

            branch.IsActive = false;
            _context.Branches.Update(branch);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Đã xóa (ẩn) chi nhánh thành công!" });
        }
    }
}
