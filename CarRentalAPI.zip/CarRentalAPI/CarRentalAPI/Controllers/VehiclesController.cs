﻿using CarRentalAPI.Data;
using CarRentalAPI.DTOs;
using CarRentalAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CarRentalAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehiclesController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public VehiclesController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // ✅ Lấy danh sách tất cả xe
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var vehicles = await _context.Vehicles
                .Include(v => v.Brand)
                .Include(v => v.Type)
                .Include(v => v.Branch)
                .Select(v => new
                {
                    v.VehicleID,
                    v.VehicleName,
                    v.BrandID,
                    BrandName = v.Brand != null ? v.Brand.BrandName : "",
                    v.TypeID,
                    TypeName = v.Type != null ? v.Type.TypeName : "",
                    v.BranchID,
                    BranchName = v.Branch != null ? v.Branch.BranchName : "",
                    v.PricePerDay,
                    v.Seats,
                    v.Description,
                    v.VehicleImage,
                    v.Status,
                    v.IsActive
                })
                .ToListAsync();

            return Ok(vehicles);
        }


        // ✅ Lấy danh sách Hãng xe để chọn
        [HttpGet("brands")]
        public async Task<IActionResult> GetBrands()
        {
            var brands = await _context.VehicleBrands
                .Select(b => new { b.BrandID, b.BrandName })
                .ToListAsync();
            return Ok(brands);
        }

        // ✅ Lấy danh sách Loại xe để chọn
        [HttpGet("types")]
        public async Task<IActionResult> GetTypes()
        {
            var types = await _context.VehicleTypes
                .Select(t => new { t.TypeID, t.TypeName })
                .ToListAsync();
            return Ok(types);
        }

        // ✅ Lấy 1 xe theo ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var vehicle = await _context.Vehicles
                .Include(v => v.Brand)
                .Include(v => v.Type)
                .Include(v => v.Branch)
                .Where(v => v.VehicleID == id)
                .Select(v => new
                {
                    v.VehicleID,
                    v.VehicleName,
                    v.BrandID,
                    BrandName = v.Brand != null ? v.Brand.BrandName : "",
                    v.TypeID,
                    TypeName = v.Type != null ? v.Type.TypeName : "",
                    v.BranchID,
                    BranchName = v.Branch != null ? v.Branch.BranchName : "",
                    v.PricePerDay,
                    v.Seats,
                    v.Description,
                    v.VehicleImage,
                    v.Status,
                    v.IsActive
                })
                .FirstOrDefaultAsync();

            if (vehicle == null) return NotFound();
            return Ok(vehicle);
        }


        [HttpPost]
        public async Task<IActionResult> Create([FromForm] VehicleCreateDTO dto)
        {
            var vehicle = new Vehicle
            {
                VehicleName = dto.VehicleName,
                BrandID = dto.BrandID,
                TypeID = dto.TypeID,
                BranchID = dto.BranchID,
                PricePerDay = dto.PricePerDay,
                Seats = dto.Seats,
                Description = dto.Description,
                Status = dto.Status,
                IsActive = dto.IsActive
            };

            if (dto.ImageFile != null)
            {
                string uploadsFolder = Path.Combine(_env.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot"), "uploads", "vehicles");
                if (!Directory.Exists(uploadsFolder))
                    Directory.CreateDirectory(uploadsFolder);

                string fileName = $"{Guid.NewGuid()}_{dto.ImageFile.FileName}";
                string filePath = Path.Combine(uploadsFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await dto.ImageFile.CopyToAsync(stream);
                }

                vehicle.VehicleImage = $"/uploads/vehicles/{fileName}";
            }

            _context.Vehicles.Add(vehicle);
            await _context.SaveChangesAsync();

            return Ok(vehicle);
        }

        // ✅ Sửa xe
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromForm] VehicleUpdateDTO dto)
        {
            var vehicle = await _context.Vehicles.FindAsync(id);
            if (vehicle == null) return NotFound();

            vehicle.VehicleName = dto.VehicleName;
            vehicle.BrandID = dto.BrandID;
            vehicle.TypeID = dto.TypeID;
            vehicle.BranchID = dto.BranchID;
            vehicle.PricePerDay = dto.PricePerDay;
            vehicle.Seats = dto.Seats;
            vehicle.Description = dto.Description;
            vehicle.Status = dto.Status;
            vehicle.IsActive = dto.IsActive;
            vehicle.UpdatedAt = DateTime.Now;

            if (dto.ImageFile != null)
            {
                string uploadsFolder = Path.Combine(_env.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot"), "uploads", "vehicles");
                if (!Directory.Exists(uploadsFolder))
                    Directory.CreateDirectory(uploadsFolder);

                string fileName = $"{Guid.NewGuid()}_{dto.ImageFile.FileName}";
                string filePath = Path.Combine(uploadsFolder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await dto.ImageFile.CopyToAsync(stream);
                }

                vehicle.VehicleImage = $"/uploads/vehicles/{fileName}";
            }

            await _context.SaveChangesAsync();
            return Ok(vehicle);
        }


        // ✅ Xóa xe
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var vehicle = await _context.Vehicles.FindAsync(id);
            if (vehicle == null) return NotFound();

            _context.Vehicles.Remove(vehicle);
            await _context.SaveChangesAsync();
            return Ok(new { message = "Đã xóa xe thành công" });
        }
    }
}
