﻿using CarRentalAPI.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using static CarRentalAPI.DTOs.UserProfileDTOs;

namespace CarRentalAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProfileController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public ProfileController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // ✅ 1. Lấy thông tin hồ sơ cá nhân
        [HttpGet("{userId}")]
        public async Task<IActionResult> GetProfile(int userId)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return NotFound("Không tìm thấy người dùng");

            var dto = new UserProfileDTO
            {
                UserID = user.UserID,
                FullName = user.FullName,
                Email = user.Email,
                Phone = user.Phone,
                Address = user.Address,
                ProfileImage = user.ProfileImage,
                IDCardImage = user.IDCardImage,
                DriverLicenseImage = user.DriverLicenseImage
            };

            return Ok(dto);
        }

        // ✅ 2. Cập nhật hồ sơ cá nhân (có upload file)
        [HttpPut("{userId}")]
        public async Task<IActionResult> UpdateProfile(
            int userId,
            [FromForm] UserProfileUpdateDTO dto,
            IFormFile? profileImage,
            IFormFile? idCardImage,
            IFormFile? driverLicenseImage)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return NotFound("Không tìm thấy người dùng");

            user.FullName = dto.FullName ?? user.FullName;
            user.Phone = dto.Phone ?? user.Phone;
            user.Address = dto.Address ?? user.Address;
            user.UpdatedAt = DateTime.Now;

            // 🔹 Upload file ảnh (nếu có)
            string uploadFolder = Path.Combine(_env.WebRootPath, "uploads", "users");
            if (!Directory.Exists(uploadFolder))
                Directory.CreateDirectory(uploadFolder);

            if (profileImage != null)
            {
                string fileName = $"{Guid.NewGuid()}_{profileImage.FileName}";
                string filePath = Path.Combine(uploadFolder, fileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                    await profileImage.CopyToAsync(stream);
                user.ProfileImage = $"/uploads/users/{fileName}";
            }

            if (idCardImage != null)
            {
                string fileName = $"{Guid.NewGuid()}_{idCardImage.FileName}";
                string filePath = Path.Combine(uploadFolder, fileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                    await idCardImage.CopyToAsync(stream);
                user.IDCardImage = $"/uploads/users/{fileName}";
            }

            if (driverLicenseImage != null)
            {
                string fileName = $"{Guid.NewGuid()}_{driverLicenseImage.FileName}";
                string filePath = Path.Combine(uploadFolder, fileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                    await driverLicenseImage.CopyToAsync(stream);
                user.DriverLicenseImage = $"/uploads/users/{fileName}";
            }

            await _context.SaveChangesAsync();
            return Ok(new { message = "Cập nhật hồ sơ thành công." });
        }

        // ✅ 3. Đổi mật khẩu
        [HttpPut("{userId}/change-password")]
        public async Task<IActionResult> ChangePassword(int userId, [FromBody] ChangePasswordDTO dto)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return NotFound("Không tìm thấy người dùng");

            // 🔹 Ở đây giả định PasswordHash lưu dạng plain-text demo, nếu dùng BCrypt hãy kiểm tra hash đúng chuẩn
            if (user.PasswordHash != dto.CurrentPassword)
                return BadRequest("Mật khẩu hiện tại không đúng");

            user.PasswordHash = dto.NewPassword;
            user.UpdatedAt = DateTime.Now;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Đổi mật khẩu thành công" });
        }

        // ✅ 4. Xem lịch sử thuê xe của người dùng
        [HttpGet("{userId}/rentals")]
        public async Task<IActionResult> GetRentalHistory(int userId)
        {
            var rentals = await _context.Rentals
                .Include(r => r.Vehicle)
                .Where(r => r.UserId == userId)
                .OrderByDescending(r => r.CreatedDate)  // Changed CreatedAt to CreatedDate
                .Select(r => new
                {
                    r.Id,  // Changed RentalID to Id
                    r.Vehicle.VehicleName,
                    r.RentalDate,  // Changed StartDateTime to RentalDate
                    r.ReturnDate,  // Changed EndDateTime to ReturnDate
                    r.Status,
                    r.TotalPrice  // Changed FinalPrice to TotalPrice
                })
                .ToListAsync();

            return Ok(rentals);
        }

        // ✅ 5. Upload ảnh đại diện riêng (AJAX)
        [HttpPut("{userId}/avatar")]
        public async Task<IActionResult> UpdateAvatar(int userId, IFormFile avatar)
        {
            var user = await _context.Users.FindAsync(userId);
            if (user == null) return NotFound();

            string uploadFolder = Path.Combine(_env.WebRootPath, "uploads", "users");
            if (!Directory.Exists(uploadFolder))
                Directory.CreateDirectory(uploadFolder);

            string fileName = $"{Guid.NewGuid()}_{avatar.FileName}";
            string filePath = Path.Combine(uploadFolder, fileName);
            using (var stream = new FileStream(filePath, FileMode.Create))
                await avatar.CopyToAsync(stream);

            user.ProfileImage = $"/uploads/users/{fileName}";
            await _context.SaveChangesAsync();

            return Ok(new { message = "Cập nhật ảnh đại diện thành công", user.ProfileImage });
        }
    }
}
