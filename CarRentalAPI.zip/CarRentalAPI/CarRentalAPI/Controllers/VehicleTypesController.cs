﻿using CarRentalAPI.Data;
using CarRentalAPI.DTOs;
using CarRentalAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CarRentalAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleTypesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public VehicleTypesController(AppDbContext context)
        {
            _context = context;
        }

        // ✅ Lấy danh sách tất cả loại xe
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var list = await _context.VehicleTypes
                .OrderByDescending(v => v.TypeID)
                .Select(v => new VehicleTypeDTO
                {
                    TypeID = v.TypeID,
                    TypeName = v.TypeName,
                    Description = v.Description
                })
                .ToListAsync();

            return Ok(list);
        }

        // ✅ Lấy loại xe theo ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var vt = await _context.VehicleTypes.FindAsync(id);
            if (vt == null) return NotFound(new { message = "Không tìm thấy loại xe!" });

            return Ok(new VehicleTypeDTO
            {
                TypeID = vt.TypeID,
                TypeName = vt.TypeName,
                Description = vt.Description
            });
        }

        // ✅ Thêm mới loại xe
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] VehicleTypeDTO dto)
        {
            if (string.IsNullOrWhiteSpace(dto.TypeName))
                return BadRequest(new { message = "Tên loại xe không được để trống!" });

            bool exists = await _context.VehicleTypes
                .AnyAsync(v => v.TypeName.ToLower() == dto.TypeName.ToLower());
            if (exists)
                return Conflict(new { message = "Tên loại xe đã tồn tại!" });

            var newType = new VehicleType
            {
                TypeName = dto.TypeName,
                Description = dto.Description
            };

            _context.VehicleTypes.Add(newType);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Thêm loại xe thành công!" });
        }

        // ✅ Cập nhật loại xe
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] VehicleTypeDTO dto)
        {
            var vt = await _context.VehicleTypes.FindAsync(id);
            if (vt == null) return NotFound(new { message = "Không tìm thấy loại xe!" });

            vt.TypeName = dto.TypeName;
            vt.Description = dto.Description;

            await _context.SaveChangesAsync();
            return Ok(new { message = "Cập nhật loại xe thành công!" });
        }

        // ✅ Xóa loại xe
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var vt = await _context.VehicleTypes.FindAsync(id);
            if (vt == null) return NotFound(new { message = "Không tìm thấy loại xe!" });

            _context.VehicleTypes.Remove(vt);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Xóa loại xe thành công!" });
        }
    }
}
