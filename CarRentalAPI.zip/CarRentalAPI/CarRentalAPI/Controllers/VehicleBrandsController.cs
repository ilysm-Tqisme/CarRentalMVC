﻿using CarRentalAPI.Data;
using CarRentalAPI.DTOs;
using CarRentalAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CarRentalAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleBrandsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public VehicleBrandsController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // ✅ Lấy danh sách tất cả hãng xe
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var brands = await _context.VehicleBrands
                .Select(b => new
                {
                    b.BrandID,
                    b.BrandName,
                    b.Description,
                    b.LogoImage,
                    b.CreatedAt
                })
                .ToListAsync();

            return Ok(brands);
        }

        // ✅ Lấy chi tiết 1 hãng xe theo ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var brand = await _context.VehicleBrands.FindAsync(id);
            if (brand == null) return NotFound(new { message = "Không tìm thấy hãng xe." });

            return Ok(brand);
        }

        // ✅ Thêm mới hãng xe (có upload ảnh logo)
        [HttpPost]
        [RequestSizeLimit(10_000_000)] // giới hạn 10MB
        public async Task<IActionResult> Create([FromForm] VehicleBrandDTO dto, IFormFile? logo)
        {
            string? logoPath = null;

            if (logo != null)
            {
                string folder = Path.Combine(_env.WebRootPath ?? "wwwroot", "uploads", "brands");
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);

                string fileName = $"{Guid.NewGuid()}_{logo.FileName}";
                string filePath = Path.Combine(folder, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await logo.CopyToAsync(stream);
                }

                logoPath = $"/uploads/brands/{fileName}";
            }

            var brand = new VehicleBrand
            {
                BrandName = dto.BrandName,
                Description = dto.Description,
                LogoImage = logoPath
            };

            _context.VehicleBrands.Add(brand);
            await _context.SaveChangesAsync();

            return Ok(new { message = "✅ Thêm hãng xe thành công!", brand });
        }

        // ✅ Cập nhật hãng xe
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromForm] VehicleBrandDTO dto, IFormFile? logo)
        {
            var brand = await _context.VehicleBrands.FindAsync(id);
            if (brand == null) return NotFound(new { message = "Không tìm thấy hãng xe." });

            brand.BrandName = dto.BrandName;
            brand.Description = dto.Description;

            if (logo != null)
            {
                string folder = Path.Combine(_env.WebRootPath ?? "wwwroot", "uploads", "brands");
                if (!Directory.Exists(folder))
                    Directory.CreateDirectory(folder);

                // Xóa logo cũ (nếu có)
                if (!string.IsNullOrEmpty(brand.LogoImage))
                {
                    string oldPath = Path.Combine(_env.WebRootPath ?? "wwwroot", brand.LogoImage.TrimStart('/'));
                    if (System.IO.File.Exists(oldPath))
                        System.IO.File.Delete(oldPath);
                }

                string fileName = $"{Guid.NewGuid()}_{logo.FileName}";
                string filePath = Path.Combine(folder, fileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await logo.CopyToAsync(stream);
                }

                brand.LogoImage = $"/uploads/brands/{fileName}";
            }

            await _context.SaveChangesAsync();

            return Ok(new { message = "✅ Cập nhật hãng xe thành công!", brand });
        }

        // ✅ Xóa hãng xe
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var brand = await _context.VehicleBrands.FindAsync(id);
            if (brand == null) return NotFound(new { message = "Không tìm thấy hãng xe." });

            // Xóa file logo nếu có
            if (!string.IsNullOrEmpty(brand.LogoImage))
            {
                string oldPath = Path.Combine(_env.WebRootPath ?? "wwwroot", brand.LogoImage.TrimStart('/'));
                if (System.IO.File.Exists(oldPath))
                    System.IO.File.Delete(oldPath);
            }

            _context.VehicleBrands.Remove(brand);
            await _context.SaveChangesAsync();

            return Ok(new { message = "🗑️ Xóa hãng xe thành công!" });
        }
    }
}
