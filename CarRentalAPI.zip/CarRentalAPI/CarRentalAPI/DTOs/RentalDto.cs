﻿namespace CarRentalAPI.DTOs
{
    // Request tạo đơn thuê
    public record CreateRentalRequest(
        int VehicleId,
        DateTime RentalDate,
        DateTime ReturnDate
    );

    // Request cập nhật đơn thuê (User cancel hoặc calculate price)
    public record UpdateRentalRequest(
        DateTime RentalDate,
        DateTime ReturnDate
    );

    // Response thuê xe chi tiết
    public class RentalResponse
    {
        public int Id { get; set; }
        public int VehicleId { get; set; }
        public string? VehicleName { get; set; }
        public string? VehicleImage { get; set; }
        public int UserId { get; set; }
        public string? UserName { get; set; }
        public string? UserPhone { get; set; }
        public DateTime RentalDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public int RentalDays { get; set; }
        public decimal DailyRate { get; set; }
        public decimal TotalPrice { get; set; }
        public decimal PaidAmount { get; set; }
        public decimal RemainingAmount { get; set; }
        public string Status { get; set; } = "";
        public string? RejectionReason { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public int? Rating { get; set; }
        public string? Review { get; set; }
    }

    // Request calculate price (realtime)
    public record CalculatePriceRequest(
        int VehicleId,
        DateTime RentalDate,
        DateTime ReturnDate
    );

    // Response calculate price
    public class CalculatePriceResponse
    {
        public int RentalDays { get; set; }
        public decimal DailyRate { get; set; }
        public decimal TotalPrice { get; set; }
    }

    // Request admin approve/reject
    public record ApproveRentalRequest(
        int RentalId,
        bool IsApproved,
        string? RejectionReason = null
    );

    // Request rating
    public record RatingRequest(
        int RentalId,
        int Rating, // 1-5
        string? Review
    );
}
