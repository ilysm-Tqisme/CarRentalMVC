﻿namespace CarRentalAPI.DTOs
{
    public class VehicleTypeDTO
    {
        public int? TypeID { get; set; }
        public string TypeName { get; set; } = string.Empty;
        public string? Description { get; set; }
    }
}
