﻿namespace CarRentalAPI.DTOs
{
    public class BranchDTO
    {
        public string BranchName { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;
        public string? Phone { get; set; }
        public string? Description { get; set; }
        public bool IsActive { get; set; } = true;

        // 🟢 Thêm dòng này để nhận file từ form
        public IFormFile? ImageFile { get; set; }
    }
}
