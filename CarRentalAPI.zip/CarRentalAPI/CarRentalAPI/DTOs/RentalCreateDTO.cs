﻿using System.ComponentModel.DataAnnotations;

namespace CarRentalAPI.DTOs
{
    public class RentalCreateDTO
    {
        public int VehicleId { get; set; }
        public int BranchPickupId { get; set; }
        public int BranchReturnId { get; set; }
        public DateTime StartDateTime { get; set; } // expect local VN or ISO
        public DateTime EndDateTime { get; set; }
        public string PaymentMethod { get; set; } = "Cash";
        public int? PromoId { get; set; }
    }
}
