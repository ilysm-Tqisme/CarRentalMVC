﻿using System.ComponentModel.DataAnnotations;

namespace CarRentalAPI.DTOs
{
    public class VehicleBrandDTO
    {
        [Required]
        public string BrandName { get; set; } = string.Empty;

        public string? Description { get; set; }

        // 🖼️ File upload (Logo hãng xe)
        
    }
}
