﻿namespace CarRentalAPI.DTOs
{
    public class RentalResponseDto
    {
        public int RentalId { get; set; }
        public int VehicleId { get; set; }
        public string VehicleName { get; set; } = string.Empty;
        public int BranchPickupId { get; set; }
        public int BranchReturnId { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }
        public int TotalDays { get; set; }
        public int TotalHours { get; set; }
        public decimal FinalPrice { get; set; }
        public string Status { get; set; } = "Pending";
    }
}
