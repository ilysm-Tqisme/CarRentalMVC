﻿namespace CarRentalAPI.DTOs
{
    public class VehicleUpdateDTO
    {
        public string VehicleName { get; set; } = string.Empty;
        public int BrandID { get; set; }
        public int TypeID { get; set; }
        public int BranchID { get; set; }
        public decimal PricePerDay { get; set; }
        public int? Seats { get; set; }
        public string? Description { get; set; }
        public string? Status { get; set; }
        public bool IsActive { get; set; }

        public IFormFile? ImageFile { get; set; } // ✅ Đổi tên khác VehicleImage
    }
}
