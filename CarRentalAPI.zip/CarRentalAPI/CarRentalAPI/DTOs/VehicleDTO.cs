﻿namespace CarRentalAPI.DTOs
{
    public class VehicleDTO
    {
        public int BranchID { get; set; }
        public string VehicleName { get; set; } = string.Empty;
        public string? Brand { get; set; }
        public string? Model { get; set; }
        public int? Year { get; set; }
        public decimal? PricePerDay { get; set; }
        public string? Status { get; set; } = "Available";
        public string? Description { get; set; }
        public bool IsActive { get; set; } = true;

        // 🟢 file ảnh xe
        public IFormFile? ImageFile { get; set; }
    }
}
