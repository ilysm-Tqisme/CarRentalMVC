﻿namespace CarRentalAPI.DTOs
{
    public class VehicleCreateDTO
    {
        public string VehicleName { get; set; } = string.Empty;
        public int BrandID { get; set; }
        public int TypeID { get; set; }
        public int BranchID { get; set; }
        public decimal PricePerDay { get; set; }
        public int? Seats { get; set; }
        public string? Description { get; set; }
        public string? Status { get; set; } = "Available";
        public bool IsActive { get; set; } = true;

        public IFormFile? ImageFile { get; set; } // ✅ đổi tên khác (không trùng VehicleImage)
    }
}
