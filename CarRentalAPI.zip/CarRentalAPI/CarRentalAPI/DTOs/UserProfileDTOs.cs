﻿namespace CarRentalAPI.DTOs
{
    public class UserProfileDTOs
    {
        public class UserProfileDTO
        {
            public int UserID { get; set; }
            public string FullName { get; set; } = string.Empty;
            public string Email { get; set; } = string.Empty;
            public string? Phone { get; set; }
            public string? Address { get; set; }
            public string? ProfileImage { get; set; }
            public string? IDCardImage { get; set; }
            public string? DriverLicenseImage { get; set; }
        }

        public class UserProfileUpdateDTO
        {
            public string? FullName { get; set; }
            public string? Phone { get; set; }
            public string? Address { get; set; }
        }

        public class ChangePasswordDTO
        {
            public string CurrentPassword { get; set; } = string.Empty;
            public string NewPassword { get; set; } = string.Empty;
        }
    }
}
