﻿using System.ComponentModel.DataAnnotations;

namespace CarRentalAPI.DTOs
{
    public class RentalUpdateStatusDTO
    {
        public string Status { get; set; } = "Pending"; // Pending | Approved | Rejected | Completed
        public string? CancellationReason { get; set; }
    }
}
