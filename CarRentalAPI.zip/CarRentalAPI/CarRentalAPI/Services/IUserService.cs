﻿using CarRentalAPI.Models;

namespace CarRentalAPI.Services
{
    public interface IUserService
    {
        Task<User?> RegisterAsync(User user, string password);
        Task<string?> LoginAsync(string email, string password);
        Task<bool> ChangePasswordAsync(int userId, string oldPassword, string newPassword);
        Task<bool> IsEmailExistAsync(string email);
        Task<bool> IsPhoneExistAsync(string phone);

    }
}
