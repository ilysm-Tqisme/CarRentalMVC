﻿using CarRentalAPI.Data;
using CarRentalAPI.DTOs;
using CarRentalAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CarRentalAPI.Services
{
    public class RentalService : IRentalService
    {
        private readonly AppDbContext _context;

        public RentalService(AppDbContext context)
        {
            _context = context;
        }

        // ===== USER: Tạo đơn thuê =====
        public async Task<RentalResponse?> CreateRentalAsync(int userId, CreateRentalRequest req)
        {
            try
            {
                // Check user exists
                var user = await _context.Users.FindAsync(userId);
                if (user == null) return null;

                // Check vehicle exists
                var vehicle = await _context.Vehicles.FindAsync(req.VehicleId);
                if (vehicle == null) return null;

                // Validate dates
                if (req.RentalDate >= req.ReturnDate)
                    throw new Exception("Ngày trả phải sau ngày mượn");

                if (req.RentalDate < DateTime.Now.Date)
                    throw new Exception("Ngày mượn không thể trong quá khứ");

                // Check vehicle available
                var conflicting = await _context.Rentals
                    .Where(r => r.VehicleId == req.VehicleId &&
                                r.Status != "Rejected" && r.Status != "Cancelled" &&
                                r.RentalDate < req.ReturnDate &&
                                r.ReturnDate > req.RentalDate)
                    .FirstOrDefaultAsync();

                if (conflicting != null)
                    throw new Exception("Xe không có sẵn trong khoảng thời gian này");

                // Calculate total price
                var rentalDays = (req.ReturnDate.Date - req.RentalDate.Date).Days;
                var totalPrice = rentalDays * vehicle.PricePerDay;

                var rental = new Rental
                {
                    UserId = userId,
                    VehicleId = req.VehicleId,
                    RentalDate = req.RentalDate.Date,
                    ReturnDate = req.ReturnDate.Date,
                    DailyRate = vehicle.PricePerDay,
                    TotalPrice = totalPrice,
                    RemainingAmount = totalPrice,
                    Status = "Pending",
                    CreatedDate = DateTime.Now
                };

                _context.Rentals.Add(rental);
                await _context.SaveChangesAsync();

                return MapToResponse(rental, vehicle, user);
            }
            catch (Exception ex)
            {
                throw new Exception($"Lỗi tạo đơn thuê: {ex.Message}");
            }
        }

        // ===== USER: Xem đơn thuê của tôi =====
        public async Task<List<RentalResponse>> GetUserRentalsAsync(int userId)
        {
            var rentals = await _context.Rentals
                .Where(r => r.UserId == userId)
                .Include(r => r.Vehicle)
                .Include(r => r.User)
                .OrderByDescending(r => r.CreatedDate)
                .ToListAsync();

            return rentals.Select(r => MapToResponse(r, r.Vehicle, r.User)).ToList();
        }

        // ===== USER: Chi tiết đơn thuê =====
        public async Task<RentalResponse?> GetRentalByIdAsync(int rentalId, int userId)
        {
            var rental = await _context.Rentals
                .Where(r => r.Id == rentalId && r.UserId == userId)
                .Include(r => r.Vehicle)
                .Include(r => r.User)
                .FirstOrDefaultAsync();

            if (rental == null) return null;
            return MapToResponse(rental, rental.Vehicle, rental.User);
        }

        // ===== USER: Hủy đơn thuê (chỉ Pending) =====
        public async Task<bool> CancelRentalAsync(int rentalId, int userId)
        {
            var rental = await _context.Rentals.FindAsync(rentalId);
            if (rental == null || rental.UserId != userId)
                return false;

            if (rental.Status != "Pending")
                throw new Exception("Chỉ có thể hủy đơn ở trạng thái chờ duyệt");

            rental.Status = "Cancelled";
            rental.UpdatedDate = DateTime.Now;
            _context.Rentals.Update(rental);
            await _context.SaveChangesAsync();
            return true;
        }

        // ===== REALTIME: Tính giá theo ngày =====
        public async Task<CalculatePriceResponse> CalculatePriceAsync(CalculatePriceRequest req)
        {
            var vehicle = await _context.Vehicles.FindAsync(req.VehicleId);
            if (vehicle == null)
                throw new Exception("Xe không tồn tại");

            if (req.RentalDate >= req.ReturnDate)
                throw new Exception("Ngày trả phải sau ngày mượn");

            var rentalDays = (req.ReturnDate.Date - req.RentalDate.Date).Days;
            var totalPrice = rentalDays * vehicle.PricePerDay;

            return new CalculatePriceResponse
            {
                RentalDays = rentalDays,
                DailyRate = vehicle.PricePerDay,
                TotalPrice = totalPrice
            };
        }

        // ===== USER: Đánh giá xe =====
        public async Task<bool> RateRentalAsync(int rentalId, int userId, RatingRequest req)
        {
            var rental = await _context.Rentals.FindAsync(rentalId);
            if (rental == null || rental.UserId != userId)
                return false;

            if (rental.Status != "Completed")
                throw new Exception("Chỉ có thể đánh giá đơn thuê hoàn thành");

            if (req.Rating < 1 || req.Rating > 5)
                throw new Exception("Đánh giá phải từ 1-5 sao");

            rental.Rating = req.Rating;
            rental.Review = req.Review;
            rental.UpdatedDate = DateTime.Now;
            _context.Rentals.Update(rental);
            await _context.SaveChangesAsync();
            return true;
        }

        // ===== ADMIN: Xem tất cả đơn thuê =====
        public async Task<List<RentalResponse>> GetAllRentalsAsync(string? status = null)
        {
            var query = _context.Rentals
                .Include(r => r.Vehicle)
                .Include(r => r.User)
                .AsQueryable();

            if (!string.IsNullOrEmpty(status))
                query = query.Where(r => r.Status == status);

            var rentals = await query.OrderByDescending(r => r.CreatedDate).ToListAsync();
            return rentals.Select(r => MapToResponse(r, r.Vehicle, r.User)).ToList();
        }

        // ===== ADMIN: Duyệt đơn thuê =====
        public async Task<RentalResponse?> ApproveRentalAsync(int rentalId, int adminId)
        {
            var rental = await _context.Rentals
                .Include(r => r.Vehicle)
                .Include(r => r.User)
                .FirstOrDefaultAsync(r => r.Id == rentalId);

            if (rental == null)
                return null;

            if (rental.Status != "Pending")
                throw new Exception("Chỉ có thể duyệt đơn ở trạng thái chờ duyệt");

            rental.Status = "Approved";
            rental.ApprovedById = adminId;
            rental.ApprovedDate = DateTime.Now;
            rental.UpdatedDate = DateTime.Now;

            _context.Rentals.Update(rental);
            await _context.SaveChangesAsync();

            return MapToResponse(rental, rental.Vehicle, rental.User);
        }

        // ===== ADMIN: Từ chối đơn thuê =====
        public async Task<RentalResponse?> RejectRentalAsync(int rentalId, int adminId, string? reason)
        {
            var rental = await _context.Rentals
                .Include(r => r.Vehicle)
                .Include(r => r.User)
                .FirstOrDefaultAsync(r => r.Id == rentalId);

            if (rental == null)
                return null;

            if (rental.Status != "Pending")
                throw new Exception("Chỉ có thể từ chối đơn ở trạng thái chờ duyệt");

            rental.Status = "Rejected";
            rental.RejectionReason = reason;
            rental.ApprovedById = adminId;
            rental.ApprovedDate = DateTime.Now;
            rental.UpdatedDate = DateTime.Now;

            _context.Rentals.Update(rental);
            await _context.SaveChangesAsync();

            return MapToResponse(rental, rental.Vehicle, rental.User);
        }

        // ===== ADMIN: Hủy đơn (Admin) =====
        public async Task<RentalResponse?> CancelRentalAdminAsync(int rentalId, int adminId, string? reason)
        {
            var rental = await _context.Rentals
                .Include(r => r.Vehicle)
                .Include(r => r.User)
                .FirstOrDefaultAsync(r => r.Id == rentalId);

            if (rental == null)
                return null;

            if (rental.Status == "Completed" || rental.Status == "Cancelled" || rental.Status == "Rejected")
                throw new Exception("Không thể hủy đơn ở trạng thái này");

            rental.Status = "Cancelled";
            rental.Notes = reason ?? "Admin hủy";
            rental.UpdatedDate = DateTime.Now;

            _context.Rentals.Update(rental);
            await _context.SaveChangesAsync();

            return MapToResponse(rental, rental.Vehicle, rental.User);
        }

        // ===== ADMIN: Thống kê =====
        public async Task<RentalStatistics> GetStatisticsAsync(DateTime? fromDate, DateTime? toDate)
        {
            var query = _context.Rentals.AsQueryable();

            if (fromDate.HasValue)
                query = query.Where(r => r.CreatedDate >= fromDate.Value);

            if (toDate.HasValue)
                query = query.Where(r => r.CreatedDate <= toDate.Value);

            var totalRentals = await query.CountAsync();
            var approvedRentals = await query.Where(r => r.Status == "Approved" || r.Status == "Active" || r.Status == "Completed").CountAsync();
            var completedRentals = await query.Where(r => r.Status == "Completed").CountAsync();
            var totalRevenue = await query.Where(r => r.Status == "Completed").SumAsync(r => r.TotalPrice);
            var avgRating = await query.Where(r => r.Rating.HasValue).AverageAsync(r => (double?)r.Rating) ?? 0;

            return new RentalStatistics
            {
                TotalRentals = totalRentals,
                ApprovedRentals = approvedRentals,
                CompletedRentals = completedRentals,
                TotalRevenue = totalRevenue,
                AvgRating = (decimal)avgRating
            };
        }

        // ===== Helper: Map to Response =====
        private RentalResponse MapToResponse(Rental rental, Vehicle? vehicle, User? user)
        {
            var rentalDays = (rental.ReturnDate.Date - rental.RentalDate.Date).Days;
            return new RentalResponse
            {
                Id = rental.Id,
                VehicleId = rental.VehicleId,
                VehicleName = vehicle?.VehicleName,
                VehicleImage = vehicle?.VehicleImage,
                UserId = rental.UserId,
                UserName = user?.FullName,
                UserPhone = user?.Phone,
                RentalDate = rental.RentalDate,
                ReturnDate = rental.ReturnDate,
                RentalDays = rentalDays,
                DailyRate = rental.DailyRate,
                TotalPrice = rental.TotalPrice,
                PaidAmount = rental.PaidAmount,
                RemainingAmount = rental.RemainingAmount,
                Status = rental.Status,
                RejectionReason = rental.RejectionReason,
                CreatedDate = rental.CreatedDate,
                ApprovedDate = rental.ApprovedDate,
                Rating = rental.Rating,
                Review = rental.Review
            };
        }
    }
}
