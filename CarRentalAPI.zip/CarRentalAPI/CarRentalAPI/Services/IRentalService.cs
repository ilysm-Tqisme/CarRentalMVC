﻿using CarRentalAPI.DTOs;

namespace CarRentalAPI.Services
{
    public interface IRentalService
    {
        // ===== USER FUNCTIONS =====
        Task<RentalResponse?> CreateRentalAsync(int userId, CreateRentalRequest req);
        Task<List<RentalResponse>> GetUserRentalsAsync(int userId);
        Task<RentalResponse?> GetRentalByIdAsync(int rentalId, int userId);
        Task<bool> CancelRentalAsync(int rentalId, int userId); // User only cancel Pending
        Task<CalculatePriceResponse> CalculatePriceAsync(CalculatePriceRequest req);
        Task<bool> RateRentalAsync(int rentalId, int userId, RatingRequest req);

        // ===== ADMIN FUNCTIONS =====
        Task<List<RentalResponse>> GetAllRentalsAsync(string? status = null);
        Task<RentalResponse?> ApproveRentalAsync(int rentalId, int adminId);
        Task<RentalResponse?> RejectRentalAsync(int rentalId, int adminId, string? reason);
        Task<RentalResponse?> CancelRentalAdminAsync(int rentalId, int adminId, string? reason);
        Task<RentalStatistics> GetStatisticsAsync(DateTime? fromDate, DateTime? toDate);
    }

    public class RentalStatistics
    {
        public int TotalRentals { get; set; }
        public int ApprovedRentals { get; set; }
        public int CompletedRentals { get; set; }
        public decimal TotalRevenue { get; set; }
        public decimal AvgRating { get; set; }
    }
}

